<?php 
	session_start();
	
	require "../model/User.php";

	if (!isset($_SESSION['hasLoggedIn'])) 
	{
		header("Location: login.php");
		exit();
	}

	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$keys=Keys();
		foreach($keys as $key)
		{
			$i='delete_'.$key;
			if(isset($_POST[$i]))
			{
				$delete_id=$key;
				DeleteUser($delete_id);
			}
		}
	}

	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$keys=Keys();
		foreach($keys as $key)
		{
			$i='confirm_'.$key;
			if(isset($_POST[$i]))
			{
				$id_up = $key;
				$uname_up = $_POST["uname_up"];
				$pass_up = $_POST["pass_up"];
				updateUser($uname_up, $pass_up, $id_up, );
				unset($_POST[$i]);
			}
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome | App</title>
</head>
<body>

	<h3> Welcome <?php echo $_SESSION['hasLoggedIn'];?> to our WelcomePage </h3>
	<hr>
	<p>
	<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$keys=Keys();
		foreach($keys as $k  )
		{
		$i="update_".$k;
		if (isset($_POST[$i])) 
		{
			$id = $k; 
			$result=fetch_user($id);
			echo "<br>";
			echo "<h1>Update </h1>";
			echo "<form action= {$_SERVER['PHP_SELF']} method='post'>";
			echo "<table border=1>";
			echo "<tr>";
			echo "<th>ID</th>";
			echo "<th>Username</th>";
			echo "<th>Password</th>";
			echo "<th>Operations 1</th>";
			echo "<th>Operations 2</th>";
			echo "</tr>";

			while ($row = $result->fetch_assoc())
			{
				echo "<tr>";
				echo "<td>" . $row['id'] . "</td>";
				echo "<td><input type='text' name='uname_up' value='" . $row['username'] . "'</td>";
				echo "<td><input type='text' name='pass_up' value='" . $row['password'] . "'</td>";
				echo "<td>". "<input type='submit' id='confirm' name='confirm_" . $row['id'] . "' value='Confirm'>";
				echo "<input type='hidden' name='update_'" . $row['id'] . "' value='" . $row['id'] . "'></td>";
				echo "</tr>";
			}
		}
	}
	}

	$result=connect();
	echo "<h1> All users </h1>";
	echo "<form action= {$_SERVER['PHP_SELF']} method='post'><table border=1>";
	echo "<tr>";
	echo "<th>id</th>";
	echo "<th>Username</th>";
	echo "<th>Password</th>";
	echo "<th>Action</th>";
	echo "</tr>";
	while ($row = $result->fetch_assoc()) {
    	echo "<tr>";
		echo "<td>" . $row['id'] . "</td>";
		echo "<td>" . $row['username'] . "</td>";
		echo "<td>" . $row['password'] . "</td>";
		echo "<td>". "<input type='submit' id='delete' name='delete_" . $row['id'] . "' value='Delete'>";
		echo "<input type='submit' id='update' name='update_" . $row['id'] . "' value='Update'>";
		echo "<input type='hidden' name='delete_'" . $row['id'] . "' value='" . $row['id'] . "'></td>";
		echo "</tr>";
	}
	echo "</table>";
	echo "</form>";
	echo "<br>";
	echo "<a href="."../controllers/Logout.php"."><b>Logout</b></a>";
		?>

</body>
<html>
<?php
function credentials($username, $password) 
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT id, username, password FROM Users WHERE username = ? and password = ?");
	$stmt->bind_param("ss", $username, $password);

	$username=$username;
	$password=$username;

	if ($stmt->execute()) {
		return true;
	}

	return false;
}

function connect()
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	$stmt = $conn->prepare("SELECT id, username, password FROM Users ");
	
	$stmt->execute();
	$result=$stmt->get_result();
	return $result;
}

function fetch_user($id)
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT id, username, password FROM USERS where id=?");
	$stmt-> bind_param("s",$d);

	$d=$id;
	$stmt->execute();
	$result=$stmt->get_result();
	return $result;
}

function updateUser($uname, $pass,$id)
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("UPDATE Users set  username=?, password=? WHERE id=?");
	$stmt ->  bind_param("sss",$uname, $pass,$id);

	$id=$id;
	$uname=$uname;
	$pass=$pass;
	$stmt->execute();
}

function DeleteUser($delete_id)
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("DELETE FROM Users WHERE id=?");
	$stmt-> bind_param("s", $id);

	$id=$delete_id;
	
	if ($stmt->execute()) {
		return true;
	}
	return false;
}

function Keys()
{
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "my_app";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT id FROM Users");
	
	$stmt->execute();
	$stmt->bind_result($id);
	$primaryKeys =[];
	while($stmt->fetch())
	{
		$primaryKeys[]=$id;
	}
	
	$stmt->close();
	$conn->close();

	return $primaryKeys;
}
?>